export default function handler(req, res) {
  res.status(200).json({
    SUPABASE_URL: "https://xwdvnjodqvwqvorbnxln.supabase.co",
    SUPABASE_ANON_KEY: "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Inh3ZHZuam9kcXZ3cXZvcmJueGxuIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTkzNDkzMzAsImV4cCI6MjA3NDkyNTMzMH0.219yAB1IUJTRbTAR3gt8h9ufkI50-TJqKej-iW9KOmM"
  });
}
